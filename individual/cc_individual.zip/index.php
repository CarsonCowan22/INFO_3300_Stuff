<?php
session_start();
include 'view/header.php';
?>
<main>
    <h1>Menu</h1>
    <ul>
        <li>
            <a href="gear">Gear</a>
        </li>
    </ul>
</main>
<?php include 'view/footer.php'; ?>