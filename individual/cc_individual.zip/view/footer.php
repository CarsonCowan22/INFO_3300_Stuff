<footer>
    <a href="/individual/index.php">home</a>
    <p class="copyright">&copy; <?php echo date("Y"); ?> The Gear Loan System</p>
</footer>
</body>
</html>