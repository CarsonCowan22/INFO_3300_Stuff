<footer>
    <a href="/exam2/index.php">home</a>
    <p class="copyright">&copy; <?php echo date("Y"); ?> The Utensil Inventory System</p>
</footer>
</body>
</html>